let body = document.querySelector("body");
let colorRandom = document.querySelector(".colorRandom");
let colorInput = document.querySelector("#colorInput");
let applyColor = document.querySelector(".applyColor");
let showColorName = document.querySelector(".showColorName");
let colorShowDetails = document.querySelector("#colorShowDetails");



let randomColorStore = ['red','blue','green','aqua','gold','black','white','yellowgreen','bisque','brown',"azure",'antiquewhite'];
const colorSound = (colorAudio) =>{
  if(colorAudio == "red" || colorAudio == "Red"){
    red.play();
  }
  else if(colorAudio == "blue" || colorAudio == "Blue"){
    blue.play();
  }
  else if(colorAudio == "black" || colorAudio == "Black"){
    black.play();
  }
  else if(colorAudio == "white" || colorAudio == "White"){
    white.play();
  }
  else if(colorAudio == "aqua" || colorAudio == "Aqua"){
    aqua.play();
  }
  else if(colorAudio == "gold" || colorAudio == "Gold"){
    gold.play();
  }
  else if(colorAudio == "yellowgreen" || colorAudio == "Yellowgreen"){
    yellowgreen.play();
  }
  else if(colorAudio == "bisque" || colorAudio == "Bisque"){
    bisque.play();
  }
  else if(colorAudio == "brown" || colorAudio == "Brown"){
    brown.play();
  }
  else if(colorAudio == "green" || colorAudio == "Green"){
    green.play();
  }
  else if(colorAudio == "antiquewhite" || colorAudio == "Antiquewhite"){
    antiquewhite.play();
  }
  else if(colorAudio == "azure" || colorAudio == "Azure"){
    azure.play();
  }
}
const randomGenerate = () =>{
    random.play();
    let generateIndex = Math.floor(Math.random()*randomColorStore.length);
    colorShowDetails.style.display = "none";    
    showColor(randomColorStore[generateIndex]);
    colorInput.value = randomColorStore[generateIndex];
}
colorRandom.addEventListener("click",randomGenerate);


const showName = (colorName) =>{
    showColorName.innerText = colorName;
    colorSound(colorName);
    }

const showColor = (color) =>{
    body.style.backgroundColor = color;
    showName(color);
}
const inputStore = () =>{
    applyaudio.play();
    let inputValue = colorInput.value;
    let colorCorrect = CSS.supports('color',inputValue)
    if(colorCorrect){
        showColor(inputValue);
        colorShowDetails.style.display = "none";
       
    }
    else {
        colorShowDetails.style.display = "block"
        colorShowDetails.innerText = "You Enter Wrong Color";
        wrongaudio.play();
     }
     
}

applyColor.addEventListener("click",inputStore);